﻿namespace MemoryGameLogic
{
    public struct Pair<T, S>
    {
        private T m_FirstArgument;
        private S m_SecondArgument;

        public Pair(T i_FirstArgument, S i_SecondArgument)
        {
            m_FirstArgument = i_FirstArgument;
            m_SecondArgument = i_SecondArgument;
        }

        public T FirstArgument
        {
            get { return m_FirstArgument; }
            set { m_FirstArgument = value; }
        }

        public S SecondArgument
        {
            get { return m_SecondArgument; }
            set { m_SecondArgument = value; }
        }
    }
}
