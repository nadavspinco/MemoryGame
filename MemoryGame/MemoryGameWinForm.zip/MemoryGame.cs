﻿namespace MemoryGameLogic
{
    public enum eTurnStatus
    {
        BeforeRevealCard = 0,
        AfterRevealCard = 1,
        WrongChoice = 2,
        CorrectChoice = 3
    }

    public enum eGameMode     
    {
        TwoPlayers = 1,
        Pc = 2
    }
    
    public class MemoryGame<T>
    {
        private const byte k_CorrectChoiceCardQuantity = 2;
        private const byte k_RowDimension = 0;
        private const byte k_ColumnDimension = 1;
        private readonly Player r_Player1;
        private readonly Player r_Player2;
        private Board<T> m_Board;
        private Pair<int, int> m_ChosenInTheFirstMove;
        private Pair<int, int> m_ChosenInTheSecondMove;
        private T m_ChosenInTheFirstMoveValue;
        private eTurnStatus m_TurnStatus;
        private Player m_CurrentPlayerTurn;
        private AiMemoryGame<T> m_AiMemoryGame;

        public MemoryGame(
            string i_PlayerUserName1, 
            string i_PlayerUserName2,
            T[,] i_ArrayOfT, 
            eGameMode i_PcOrTwoPlayers)
        {
            const bool v_IsPc = true;
            m_Board = new Board<T>(i_ArrayOfT);

            r_Player1 = new Player(i_PlayerUserName1, !v_IsPc);
            r_Player2 = i_PcOrTwoPlayers == eGameMode.TwoPlayers
                ? new Player(i_PlayerUserName2, !v_IsPc)
                : new Player(i_PlayerUserName2, v_IsPc);

            m_CurrentPlayerTurn = r_Player1;

            if (i_PcOrTwoPlayers == eGameMode.Pc)
            {
                m_AiMemoryGame = new AiMemoryGame<T>(m_Board);
            }

            m_TurnStatus = eTurnStatus.BeforeRevealCard;
        }

        public Player CurrentPlayer
        {
            get { return m_CurrentPlayerTurn; }
        }

        public Pair<int, int> GetMoveFromAi()
        {
            return m_AiMemoryGame.CreateMove();
        }

        public bool isGameOn()
        {
            return m_Board.AmountOfCoveredCell > 0;
        }

        public T PressedCell(Pair<int, int> i_Choice, ref eTurnStatus io_TurnStatus)
        {
            T valueOfChoice = m_Board.GetValue(i_Choice);
            eCellChoice cellChoice = m_Board.GetCellStatus(i_Choice);
            const bool v_Visible = true; 

            if (cellChoice == eCellChoice.Valid && m_TurnStatus != eTurnStatus.WrongChoice &&
                m_TurnStatus != eTurnStatus.CorrectChoice)
            {
                m_Board.SetCellVisibility(i_Choice, v_Visible);

                if (m_AiMemoryGame != null)
                {
                    m_AiMemoryGame.Evaluate(i_Choice, valueOfChoice);
                }

                if (m_TurnStatus == eTurnStatus.BeforeRevealCard)
                {
                    m_ChosenInTheFirstMove = i_Choice;
                    m_ChosenInTheFirstMoveValue = m_Board.GetValue(i_Choice);
                    m_TurnStatus = io_TurnStatus = eTurnStatus.AfterRevealCard;
                }
                else if (m_TurnStatus == eTurnStatus.AfterRevealCard)
                {
                    m_ChosenInTheSecondMove = i_Choice;

                    if (object.Equals(m_ChosenInTheFirstMoveValue, m_Board.GetValue(i_Choice)))
                    {
                        m_TurnStatus = io_TurnStatus = eTurnStatus.CorrectChoice;
                    }
                    else
                    {
                        m_TurnStatus = io_TurnStatus = eTurnStatus.WrongChoice;
                    }

                    determineTurn();
                }
            }

            return valueOfChoice;
        }

        private eTurnStatus determineTurn()
        {
            eTurnStatus isCorrectChoice = m_TurnStatus;
            const bool v_Visible = true;

            if (m_TurnStatus == eTurnStatus.CorrectChoice)
            {
                m_Board.AmountOfCoveredCell -= k_CorrectChoiceCardQuantity;
                ++m_CurrentPlayerTurn;
                isCorrectChoice = eTurnStatus.CorrectChoice;
            }
            else if (m_TurnStatus == eTurnStatus.WrongChoice)
            {
                m_Board.SetCellVisibility(m_ChosenInTheFirstMove, !v_Visible);
                m_Board.SetCellVisibility(m_ChosenInTheSecondMove, !v_Visible);

                if (m_CurrentPlayerTurn == r_Player1)
                {
                    m_CurrentPlayerTurn = r_Player2;
                }
                else
                {
                    m_CurrentPlayerTurn = r_Player1;
                }

                if (m_AiMemoryGame != null)
                {
                    m_AiMemoryGame.AddToValidCards(m_ChosenInTheFirstMove);
                    m_AiMemoryGame.AddToValidCards(m_ChosenInTheSecondMove);
                }
            }

            m_TurnStatus = eTurnStatus.BeforeRevealCard;

            return isCorrectChoice;
        }

        public Board<T> Board
        {
            get { return m_Board; }
        }

        public Player Player1
        {
            get { return r_Player1; }
        }

        public Player Player2
        {
            get
            {
                return r_Player2;
            }
        }
        

        public eTurnStatus TurnStatus
        {
            get { return m_TurnStatus; }
        }
    }
}
