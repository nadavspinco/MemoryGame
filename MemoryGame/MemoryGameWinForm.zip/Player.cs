﻿namespace MemoryGameLogic
{
   public class Player
    {
        protected readonly bool r_IsThePlayerPc;
        protected string m_Name;
        protected int m_Score;

        public Player(string i_Name, bool i_IsThePlayerPc)
        {
            m_Name = i_Name;
            m_Score = 0;
            r_IsThePlayerPc = i_IsThePlayerPc;
        }

        public string Name
        {
            get { return m_Name; }
            set
            {
                if (!r_IsThePlayerPc)
                {
                    m_Name = value;
                }
            }
        }

        public static Player operator ++(Player i_Player)
        {
            ++i_Player.m_Score;
            return i_Player;
        }

        public bool IsThePlayerPc
        {
            get { return r_IsThePlayerPc; }
        }

        public int Score
        {
            get { return m_Score; }
        }
    }
}
