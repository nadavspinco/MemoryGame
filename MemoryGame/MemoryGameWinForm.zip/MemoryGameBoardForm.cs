﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Net;
using System.Text;
using System.Windows.Forms;
using MemoryGameLogic;

namespace MemoryGameUi
{
   public class MemoryGameBoardForm: Form
   {
       private readonly Size r_CellSize = new System.Drawing.Size(85,85);
       private BoardButton[,] m_Buttons;
       private Point m_CurrentPoint = new Point(10,10);
       private Label m_currentPlayerLabel;
       private Label m_firstPlayerScoreLabel;
       private Label m_SecondPlayerScoreLabel;
       private BoardButton m_ChosenInFirstTurn;
       private BoardButton m_ChosenInSecondTurn;
       private MemoryGame<Image> m_MemoryGame;
       private readonly Timer m_CleanWrongChoiceTimer;
       private readonly Color r_FirstPlayerColor = Color.LightGreen;
       private readonly Color r_SecondPlayerColor = Color.MediumPurple;
       private eTurnStatus m_turnStatus;
       private readonly List<BoardButton> m_DisabledValidButtons;
       private readonly Timer m_AiTimer;
       private const int k_SecondAndHalfInMilSeconds = 1500;
       private const int k_AmountOfPixelsForPictureBox = 95;
       private const int k_AmountOfPixelsForSpacing = 10;
       public MemoryGameBoardForm(int i_RowSize, int i_ColSize,string i_FirstPlayerName, string i_SecondPlayerName, eGameMode i_PcOrTwoiPlayers)
       {
           m_DisabledValidButtons = new List<BoardButton>();
           m_AiTimer = new Timer();
           m_AiTimer.Interval = k_SecondAndHalfInMilSeconds;
           m_AiTimer.Tick += makePcTurn;
           m_CleanWrongChoiceTimer = new Timer();
           m_CleanWrongChoiceTimer.Tick += onWrongChoice;
            m_CleanWrongChoiceTimer.Interval = k_SecondAndHalfInMilSeconds;
            m_turnStatus = eTurnStatus.BeforeRevealCard;
            
            m_MemoryGame = new MemoryGame<Image>(i_FirstPlayerName,
                i_SecondPlayerName,
                createMatrixOfAnyObject(i_RowSize,i_ColSize,makeImageList(i_RowSize,i_ColSize)) , i_PcOrTwoiPlayers);
            InitializeComponent();
       }

     

        private string makeScroeLabelText(int i_Score, string i_PlayerName)
       {
           return string.Format("{0}: {1} Pairs", i_PlayerName, i_Score);
       }

        private string makeCurrentPlayerLabelText(string i_PlayerName)
        {
            return string.Format("Current Player: {0}", i_PlayerName);
        }

        private void setCurrentPlayerLabel()
        {
            Player currentPlayer = m_MemoryGame.CurrentPlayer;
            Color toSetColor = getCurrentPlayerColor();
            m_currentPlayerLabel.Text = makeCurrentPlayerLabelText(currentPlayer.Name);
            m_currentPlayerLabel.BackColor = toSetColor;
        }

        private void InitializeComponent()
        {
            this.Text = "Memory Game";
            this.ClientSize = new System.Drawing.Size
                (m_MemoryGame.Board.ColAmount * k_AmountOfPixelsForPictureBox  + k_AmountOfPixelsForSpacing,
                m_MemoryGame.Board.RowAmount * k_AmountOfPixelsForPictureBox + k_AmountOfPixelsForPictureBox);
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            MaximizeBox = false;
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            int rowSize = m_MemoryGame.Board.RowAmount;
            int colSize = m_MemoryGame.Board.ColAmount;
            m_Buttons = new BoardButton[rowSize, colSize];
            for (int i = 0; i < rowSize; i++)
            {
                for (int j = 0; j < colSize; j++)
                {
                    m_Buttons[i, j] = new BoardButton(i, j);
                    m_Buttons[i, j].Size = r_CellSize;
                    m_Buttons[i, j].Location = new Point(m_CurrentPoint.X, m_CurrentPoint.Y);
                    m_CurrentPoint.X += k_AmountOfPixelsForPictureBox;
                    m_Buttons[i, j].Click += gameBoardButtonClick;
                    this.Controls.Add(m_Buttons[i, j]);
                }
                m_CurrentPoint.Y += k_AmountOfPixelsForPictureBox;
                m_CurrentPoint.X = k_AmountOfPixelsForSpacing;
            }
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;

            m_currentPlayerLabel = new Label();
            m_currentPlayerLabel.Text = makeCurrentPlayerLabelText(m_MemoryGame.Player1.Name);
            m_currentPlayerLabel.Location = new Point(m_CurrentPoint.X, m_CurrentPoint.Y);
            m_currentPlayerLabel.BackColor = r_FirstPlayerColor;
            m_currentPlayerLabel.AutoSize = true;
            this.Controls.Add(m_currentPlayerLabel);

            m_CurrentPoint.Y += m_currentPlayerLabel.Size.Height + k_AmountOfPixelsForSpacing;

            m_firstPlayerScoreLabel = new Label();
            m_firstPlayerScoreLabel.Location = new Point(m_CurrentPoint.X, m_CurrentPoint.Y);
            m_firstPlayerScoreLabel.Text = makeScroeLabelText(0, m_MemoryGame.Player1.Name);
            m_firstPlayerScoreLabel.AutoSize = true;
            m_firstPlayerScoreLabel.BackColor = r_FirstPlayerColor;
            this.Controls.Add(m_firstPlayerScoreLabel);

            m_CurrentPoint.Y += m_currentPlayerLabel.Size.Height + k_AmountOfPixelsForSpacing;

            m_SecondPlayerScoreLabel = new Label();
            m_SecondPlayerScoreLabel.Location = new Point(m_CurrentPoint.X, m_CurrentPoint.Y);
            m_SecondPlayerScoreLabel.Text = makeScroeLabelText(0, m_MemoryGame.Player2.Name);
            m_SecondPlayerScoreLabel.AutoSize = true;
            m_SecondPlayerScoreLabel.BackColor = r_SecondPlayerColor;
            this.Controls.Add(m_SecondPlayerScoreLabel);
        }


       private T[,] createMatrixOfAnyObject<T>(int i_RowSize, int i_ColSize, List<T> i_List)
        {
            Random random = new Random();
            List<T> tempList = new List<T>(i_List.Capacity * 2);
            foreach (var element in i_List)
            {
                tempList.Add(element);
                tempList.Add(element);
            }
            T[,] generalMatrix = new T[i_RowSize, i_ColSize];
            for (int i = 0; i < i_RowSize; i++)
            {
                for (int j = 0; j < i_ColSize; j++)
                {
                    int randomIndex = random.Next(tempList.Count);
                    generalMatrix[i, j] = tempList[randomIndex];
                    tempList.RemoveAt(randomIndex);
                }
            }

            return generalMatrix;
        }

      

        private void gameBoardButtonClick(object sender, EventArgs e)
        {
            
            BoardButton theSender = (sender as BoardButton);
            if ( m_turnStatus == eTurnStatus.AfterRevealCard || m_turnStatus == eTurnStatus.BeforeRevealCard)
            {
                theSender.Image =
                    m_MemoryGame.PressedCell(theSender.LocationInBoard, ref m_turnStatus);
                theSender.Enabled = false;
                if (eTurnStatus.AfterRevealCard == m_turnStatus)
                {
                    m_ChosenInFirstTurn = theSender;
                }
                else
                {
                    shutDownAllBoardLegalButtons();
                    m_ChosenInSecondTurn = theSender;
                    if (eTurnStatus.WrongChoice == m_turnStatus)
                    {
                        m_AiTimer.Enabled = false;
                        m_CleanWrongChoiceTimer.Enabled = true;
                       
                      
                    }
                    else if (eTurnStatus.CorrectChoice == m_turnStatus)
                    {
                        m_DisabledValidButtons.Remove(m_ChosenInFirstTurn);
                        m_DisabledValidButtons.Remove(m_ChosenInSecondTurn);
                        theSender.Enabled = false;
                        setButtonsColor();
                        setCurrentPlayerScoreLabel();
                        if (!m_MemoryGame.CurrentPlayer.IsThePlayerPc)
                        {
                            resetAllDelayedButtons();
                            m_AiTimer.Enabled = false;
                        }
                        else
                        {
                            resetAllDelayedButtons();
                        }

                    }
                    m_turnStatus = m_MemoryGame.TurnStatus;
                    
                }

            }

            if (!m_MemoryGame.isGameOn())
            {
                onGameOver();
            }
            
        }

        private void setCurrentPlayerScoreLabel()
        {
            Label currentPlayerScoreLabel = getCurrentPlayerScoreLabel();
            currentPlayerScoreLabel.Text =
                makeScroeLabelText(m_MemoryGame.CurrentPlayer.Score, m_MemoryGame.CurrentPlayer.Name);
        }

        private void makePcTurn(object sender, EventArgs e)
        {
            
            if (m_MemoryGame.CurrentPlayer.IsThePlayerPc == true && m_MemoryGame.isGameOn())
            {
                Pair<int, int> move = m_MemoryGame.GetMoveFromAi();
                gameBoardButtonClick(m_Buttons[move.FirstArgument, move.SecondArgument], null);
            }

           
        }



        private void setButtonsColor()
        {
            m_ChosenInSecondTurn.BackColor = m_ChosenInFirstTurn.BackColor = getCurrentPlayerColor();
        }

        private Color getCurrentPlayerColor()
        {
            Color toSetColor;
            if (m_MemoryGame.CurrentPlayer == m_MemoryGame.Player1)
            {
                toSetColor = r_FirstPlayerColor;
            }
            else
            {
                toSetColor = r_SecondPlayerColor;
            }

            return toSetColor;
        }

        
        private void onWrongChoice(object sender, EventArgs e)
        {
            m_CleanWrongChoiceTimer.Enabled = false;
            m_ChosenInFirstTurn.Clear();
            m_ChosenInSecondTurn.Clear();
            m_turnStatus = m_MemoryGame.TurnStatus;
            if (!m_MemoryGame.CurrentPlayer.IsThePlayerPc)
            {
                resetAllDelayedButtons();
                m_AiTimer.Enabled = false;
            }
            else
            {
                m_AiTimer.Enabled = true;
            }

            setCurrentPlayerLabel();
        }

        private Label getCurrentPlayerScoreLabel()
        {
            Label toReturnLabel;
            if (m_MemoryGame.CurrentPlayer == m_MemoryGame.Player1)
            {
                toReturnLabel = m_firstPlayerScoreLabel;
            }
            else
            {
                toReturnLabel = m_SecondPlayerScoreLabel;
            }

            return toReturnLabel;
        }

        private void shutDownAllBoardLegalButtons()
        {
            foreach (var control in Controls)
            {
                if (control is BoardButton)
                {
                    if ((control as  BoardButton).Enabled == true)
                    {
                        m_DisabledValidButtons.Add(control as BoardButton);
                        (control as BoardButton).Enabled = false;
                    }
                }
            }
        }

        private void resetAllDelayedButtons()
        {
            foreach (var button in m_DisabledValidButtons)
            {
                button.Enabled = true;
            }
            m_DisabledValidButtons.Clear();
        }

        private List<Image> makeImageList(int i_RowSize, int i_ColSize)
        {
            List<Image> imageList = new List<Image>( i_RowSize * i_ColSize);
            var converter = new ImageConverter();
            using (var client = new WebClient())
            {
                for (int i = 0; i < (i_RowSize * i_ColSize) / 2; i++)
                {
                    var imageData = client.DownloadData(@"https://picsum.photos/80");
                    var image = (Image)converter.ConvertFrom(imageData);
                    imageList.Add(image);
                }


            }

            return imageList;
        }

        private void onGameOver()
        {
            MessageBoxButtons messageBoxBoxButtons = MessageBoxButtons.YesNo;
             DialogResult messageBoxDialogResult = MessageBox.Show(makeFinalScoreString(), "End Game", messageBoxBoxButtons);
             DialogResult = messageBoxDialogResult;
            this.Close();
        }

        private string makeFinalScoreString()
        {
            StringBuilder finalScoreString = new StringBuilder();
            int PlayerOneScore = m_MemoryGame.Player1.Score;
            int PlayerTwoScore = m_MemoryGame.Player2.Score;
            if (PlayerTwoScore == PlayerOneScore)
            {
                finalScoreString.Append(string.Format("It Is A tie!{0}",System.Environment.NewLine));
            }
            else if(PlayerTwoScore <= PlayerOneScore)
            {
                finalScoreString.Append(string.Format("{0} Is the Winner!{1}",m_MemoryGame.Player1.Name, System.Environment.NewLine));
            }
            else
            {
                finalScoreString.Append(string.Format("{0} Is the Winner!{1}", m_MemoryGame.Player2.Name, System.Environment.NewLine));
            }

            finalScoreString.Append(m_firstPlayerScoreLabel.Text);
            finalScoreString.Append(System.Environment.NewLine);
            finalScoreString.Append(m_SecondPlayerScoreLabel.Text);
            finalScoreString.Append(System.Environment.NewLine);
            finalScoreString.Append("Press Yes to Restart or No To Quit");
            return finalScoreString.ToString();
        }
    }
}
