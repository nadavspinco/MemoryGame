﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using MemoryGameLogic;

namespace MemoryGameUi
{
    public class BoardButton : PictureBox
    {
        private static Image s_DeflutImage  =  global::MemoryGame.Properties.Resources.ButtonDeafultPicture; 
        private Pair<int, int> m_LocationInBoard;

        public BoardButton(int i_Row, int i_Col)
        {
            m_LocationInBoard = new Pair<int, int>(i_Row, i_Col);
            Image = s_DeflutImage;
            this.SizeMode = PictureBoxSizeMode.CenterImage;
        }

        public Pair<int, int> LocationInBoard
        {
            get { return m_LocationInBoard; }
        }
        
        public void Clear()
        {
            Text = "";
            Enabled = true;
            Image = s_DeflutImage;
            

        }
    }
}
