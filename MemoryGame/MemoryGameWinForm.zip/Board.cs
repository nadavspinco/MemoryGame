﻿namespace MemoryGameLogic
{
    public enum eCellChoice
    {
        Valid = 0,
        OutOfBoundaries = 1,
        ChoseBefore = 2
    }

    public class Board<T>
    {
        private const byte k_RowDimension = 0;
        private const byte k_ColumnDimension = 1;
        private readonly Cell[,] r_CellsArray;
        private readonly int r_RowSize;
        private readonly int r_ColSize;
        private int m_AmountOfCoveredCells;
        
        public Board(T[,] i_ArrayOfT)
        {
            r_RowSize = i_ArrayOfT.GetLength(k_RowDimension);
            r_ColSize = i_ArrayOfT.GetLength(k_ColumnDimension);
            r_CellsArray = new Cell[r_RowSize, r_ColSize];
            m_AmountOfCoveredCells = r_RowSize * r_ColSize;

            for (int i = 0; i < r_RowSize; i++)
            {
                for (int j = 0; j < r_ColSize; j++)
                {
                    r_CellsArray[i, j] = new Cell(i, j, i_ArrayOfT[i, j]);
                }
            }
        }

        public Board(Board<T> i_Board)
        {
            r_ColSize = i_Board.r_ColSize;
            r_RowSize = i_Board.r_RowSize;
            r_CellsArray = new Cell[r_RowSize, r_ColSize];

            for (int i = 0; i < r_RowSize; i++)
            {
                for (int j = 0; j < r_ColSize; j++)
                {
                    r_CellsArray[i, j] = new Cell(i_Board.r_CellsArray[i, j]);
                }
            }

            m_AmountOfCoveredCells = i_Board.m_AmountOfCoveredCells;
        }

        public int RowAmount
        {
            get { return r_RowSize; }
        }

        public int ColAmount
        {
            get { return r_ColSize; }
        }

        private Cell getCell(Pair<int, int> i_Choice)
        {
            return r_CellsArray[i_Choice.FirstArgument, i_Choice.SecondArgument];
        }

        private bool isOutOfBoundaries(Pair<int, int> i_cell)
        {
            bool isOutOfBoundaries = false;

            if (r_RowSize <= i_cell.FirstArgument || i_cell.FirstArgument < 0)
            {
                isOutOfBoundaries = true;
            }
            else if (r_ColSize <= i_cell.SecondArgument || i_cell.SecondArgument < 0)
            {
                isOutOfBoundaries = true;
            }

            return isOutOfBoundaries;
        }

        public int AmountOfCoveredCell
        {
            get { return m_AmountOfCoveredCells; }
            set { m_AmountOfCoveredCells = value; }
        }

        public T GetValue(Pair<int, int> i_Choice)
        {
            Cell c = getCell(i_Choice);
            return c.Value;
        }

        public void SetCellVisibility(Pair<int, int> i_Choice, bool i_VisibilityToSet)
        {
            Cell c = getCell(i_Choice);
            r_CellsArray[c.RowNumber, c.ColumnNumber].Revealed = i_VisibilityToSet;
        }

        private struct Cell
        {
            private T m_Value;
            private int m_RowNumber;
            private int m_ColumnNumber;
            private bool m_Revealed;

            public Cell(int i_RowNumber, int i_ColumnNumber, T i_Value)
            {
                m_Value = i_Value;
                m_RowNumber = i_RowNumber;
                m_ColumnNumber = i_ColumnNumber;
                m_Revealed = false;
            }

            public Cell(Cell i_Cell)
            {
                m_Value = i_Cell.Value;
                m_RowNumber = i_Cell.RowNumber;
                m_ColumnNumber = i_Cell.ColumnNumber;
                m_Revealed = i_Cell.Revealed;
            }

            public T Value
            {
                get { return m_Value; }
            }

            public int ColumnNumber
            {
                get { return m_ColumnNumber; }
                set { m_ColumnNumber = value; }
            }

            public int RowNumber
            {
                get { return m_RowNumber; }
                set { m_RowNumber = value; }
            }

            public bool Revealed
            {
                get { return m_Revealed; }
                set { m_Revealed = value; }
            }

            public override string ToString()
            {
                string cellToString;

                if (!m_Revealed)
                {
                    cellToString = " ";
                }
                else
                {
                    cellToString = m_Value.ToString();
                }

                return cellToString;
            }
        }

        public eCellChoice GetCellStatus(Pair<int, int> i_Choice)
        {
            eCellChoice cellChoice;

            if (!isOutOfBoundaries(i_Choice))
            {
                Cell c = getCell(i_Choice);

                if (c.Revealed == true)
                {
                    cellChoice = eCellChoice.ChoseBefore;
                }
                else
                {
                    cellChoice = eCellChoice.Valid;
                }
            }
            else
            {
                cellChoice = eCellChoice.OutOfBoundaries;
            }

            return cellChoice;
        }
    }
}