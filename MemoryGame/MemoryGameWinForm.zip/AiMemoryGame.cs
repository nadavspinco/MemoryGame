﻿using System;
using System.Collections.Generic;

namespace MemoryGameLogic
{
    public class AiMemoryGame<T>
    {
        public Stack<Pair<int, int>> m_SmartMoves;
        private Dictionary<Pair<int, int>, T> m_ExposedCells;
        private List<Pair<int, int>> m_UnExposedCells;
        private List<Pair<int, int>> m_ValidCells;
        private Board<T> m_Board;

        public AiMemoryGame(Board<T> i_Board)
        {
            m_Board = i_Board;
            int rowSize = m_Board.RowAmount;
            int colSize = m_Board.ColAmount;
            m_ValidCells = new List<Pair<int, int>>(rowSize * colSize);
            m_UnExposedCells = new List<Pair<int, int>>(rowSize * colSize);

            for (int i = 0; i < rowSize; i++)
            {
                for (int j = 0; j < colSize; j++)
                {
                    m_ValidCells.Add(new Pair<int, int>(i, j));
                    m_UnExposedCells.Add(new Pair<int, int>(i, j));
                }
            }

            m_ExposedCells = new Dictionary<Pair<int, int>, T>(rowSize * colSize);
        }

        private void addToSmartMoves(Pair<int, int> i_Pair)
        {
            if (m_SmartMoves == null)
            {
                m_SmartMoves = new Stack<Pair<int, int>>();
            }

            m_SmartMoves.Push(i_Pair);
        }

        public void Evaluate(Pair<int, int> i_Pair, T i_Value)
        {
            m_ValidCells.Remove(i_Pair);
            m_UnExposedCells.Remove(i_Pair);
            bool isValueAlreadyExposedFlag = false;

            // Check If i_Value Already Exists In ExposedCells 
            foreach (var revealedCell in m_ExposedCells)
            {
                if (revealedCell.Value.Equals(i_Value))
                {
                    isValueAlreadyExposedFlag = true;

                    if (!revealedCell.Key.Equals(i_Pair))
                    {
                        addToSmartMoves(i_Pair);
                        addToSmartMoves(revealedCell.Key);
                    }

                    break;
                }
            }

            if (!isValueAlreadyExposedFlag)
            {
                m_ExposedCells.Add(i_Pair, i_Value);
            }
        }

        private bool existsInValidCards(Pair<int, int> i_Pair)
        {
            return m_Board.GetCellStatus(i_Pair) == eCellChoice.Valid;
        }

        public void AddToValidCards(Pair<int, int> i_Pair)
        {
            m_ValidCells.Add(i_Pair);
        }

        public Pair<int, int> CreateMove()
        {
            Pair<int, int> move = new Pair<int, int>(); 
            bool isThereASmartAndValidMoveFlag = false;

            while (m_SmartMoves != null && m_SmartMoves.Count > 0)
            {
                move = m_SmartMoves.Pop();

                if (existsInValidCards(move))
                {
                    isThereASmartAndValidMoveFlag = true;
                    break;
                }
            }

            if (!isThereASmartAndValidMoveFlag)
            {
                Random random = new Random();

                if (m_UnExposedCells.Count > 0)
                {
                    int randomIndex = random.Next(m_UnExposedCells.Count);
                    move = m_UnExposedCells[randomIndex];
                }
                else
                {
                    int randomIndex = random.Next(m_ValidCells.Count);
                    move = m_ValidCells[randomIndex];
                }
            }

            return move;
        }
    }
}
